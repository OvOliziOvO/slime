﻿Cubiomes latest build
Minecraft support: 1.19 - 26.2
Put cubiomes.dll next to SlimeFinder_NVIDIA_10_50.exe or SlimeFinder.py.
Source: https://github.com/Conflux-Union/cubiomes
