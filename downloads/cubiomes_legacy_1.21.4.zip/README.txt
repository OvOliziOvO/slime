﻿Cubiomes legacy build
Minecraft support: 1.19 - 1.21.4
Put cubiomes.dll next to SlimeFinder_NVIDIA_10_50.exe or SlimeFinder.py.
Source: https://github.com/Cubitect/cubiomes
